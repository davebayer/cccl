#include <cub/device/device_scan.cuh>
#include <cub/device/dispatch/dispatch_rle_encode.cuh>

#include <cstdint>
#include <stdexcept>
#include <string>
#include <vector>

#include <nvbench/nvbench.cuh>

void ok(cudaError_t status)
{
  if (status != cudaSuccess)
  {
    throw std::runtime_error(cudaGetErrorString(status));
  }
}
template <class T>
struct device_buf
{
  T* p{};
  explicit device_buf(size_t n)
  {
    ok(cudaMalloc(&p, n * sizeof(T)));
  }
  ~device_buf()
  {
    cudaFree(p);
  }
  T at(size_t k) const
  {
    T v;
    ok(cudaMemcpy(&v, p + k, sizeof(T), cudaMemcpyDeviceToHost));
    return v;
  }
};
template <class T>
__global__ void fill(T* p, size_t count, int run)
{
  for (size_t i = threadIdx.x + (size_t(blockIdx.x) * blockDim.x); i < count; i += size_t(gridDim.x) * blockDim.x)
  {
    p[i] = (run == 0) ? 1 : static_cast<T>(i / static_cast<unsigned>(run));
  }
}

template <class T>
void scan_work(nvbench::state& state)
{
  const auto n    = static_cast<size_t>(state.get_int64("N"));
  const auto mode = state.get_int64("Layout");
  device_buf<T> input(n);
  const device_buf<T> output(n + 1);
  auto* dst    = mode == 2 ? input.p : output.p + mode;
  size_t bytes = 0;
  auto call    = [&](void* tmp, cudaStream_t stream) {
    return cub::DeviceScan::ExclusiveSum(tmp, bytes, input.p, dst, n, stream);
  };
  ok(call(nullptr, nullptr));
  device_buf<unsigned char> tmp(bytes);
  fill<<<256, 256>>>(input.p, n, 0);
  ok(cudaMemset(output.p, 0xfd, (n + 1) * sizeof(T)));
  ok(call(tmp.p, nullptr));
  ok(cudaDeviceSynchronize());
  const auto offset = mode == 1 ? 1 : 0;
  const auto& buf   = mode == 2 ? input : output;
  for (const auto i : {size_t(0), n / 2, n - 1})
  {
    if (buf.at(offset + i) != static_cast<T>(i))
    {
      throw std::runtime_error("scan sample mismatch");
    }
  }
  if (mode == 1 && output.at(0) == T{0})
  {
    throw std::runtime_error("bad shifted prefix");
  }
  if (mode == 2)
  {
    ok(cudaMemset(input.p, 0, n * sizeof(T))); // Fixed input for repeated in-place calls
  }
  ok(cudaDeviceSynchronize());
  state.add_element_count(n);
  state.add_global_memory_reads<T>(n);
  state.add_global_memory_writes<T>(n);
  state.exec(nvbench::exec_tag::gpu | nvbench::exec_tag::no_batch, [&](nvbench::launch& launch) {
    ok(call(tmp.p, launch.get_stream()));
  });
}
void scan_u32(nvbench::state& s)
{
  scan_work<uint32_t>(s);
}
void scan_u64(nvbench::state& s)
{
  scan_work<uint64_t>(s);
}
NVBENCH_BENCH(scan_u32).add_int64_power_of_two_axis("N", {16, 20, 25}).add_int64_axis("Layout", {0, 1, 2});
NVBENCH_BENCH(scan_u64).add_int64_power_of_two_axis("N", {16, 20, 25}).add_int64_axis("Layout", {0, 1, 2});
template <bool Compact>
struct forced_rle
{
  __host__ __device__ constexpr cub::RleEncodePolicy operator()(cuda::compute_capability) const
  {
    return {cub::RleAlgorithm::lookahead,
            {128, 4, cub::BLOCK_LOAD_DIRECT, cub::LOAD_DEFAULT, cub::BLOCK_SCAN_WARP_SCANS, {}},
            {Compact ? 8 : 32, 8, 5, 3, 5, 3, 128, 32}};
  }
};
template <bool Compact>
void rle_work(nvbench::state& state)
{
  const auto n = static_cast<int32_t>(state.get_int64("N"));
  const auto r = static_cast<int32_t>(state.get_int64("Run"));
  device_buf<uint32_t> input(n);
  device_buf<uint32_t> output(n);
  device_buf<int32_t> counts(n);
  device_buf<int32_t> num_runs(1);
  size_t bytes = 0;
  auto call    = [&](void* tmp, cudaStream_t stream) {
    return cub::detail::rle::encode::dispatch(
      tmp, bytes, input.p, output.p, counts.p, num_runs.p, n, stream, forced_rle<Compact>{});
  };
  ok(call(nullptr, nullptr));
  device_buf<unsigned char> tmp(bytes);
  fill<<<256, 256>>>(input.p, n, r);
  ok(call(tmp.p, nullptr));
  ok(cudaDeviceSynchronize());
  if (num_runs.at(0) != n / r)
  {
    throw std::runtime_error("RLE count mismatch");
  }
  for (auto i : {0, n / r / 2, (n / r) - 1})
  {
    if (output.at(i) != static_cast<unsigned>(i) || counts.at(i) != r)
    {
      throw std::runtime_error("RLE sample mismatch");
    }
  }
  state.add_element_count(n);
  state.add_global_memory_reads<uint32_t>(n);
  state.add_global_memory_writes<uint32_t>(n / r);
  state.add_global_memory_writes<int32_t>((n / r) + 1);
  state.exec(nvbench::exec_tag::gpu | nvbench::exec_tag::no_batch, [&](nvbench::launch& launch) {
    ok(call(tmp.p, launch.get_stream()));
  });
}
void rle_staged(nvbench::state& s)
{
  rle_work<true>(s);
}
void rle_floor(nvbench::state& s)
{
  rle_work<false>(s);
}
NVBENCH_BENCH(rle_staged).add_int64_power_of_two_axis("N", {16, 20, 25}).add_int64_axis("Run", {1, 16, 256});
NVBENCH_BENCH(rle_floor).add_int64_power_of_two_axis("N", {16, 20, 25}).add_int64_axis("Run", {1, 16, 256});
