"""Run the archived CUB scan and RLE executables on the requested GPU."""
import argparse, pathlib, subprocess, os, json, re, time
from datetime import datetime,timezone
root=pathlib.Path(__file__).resolve().parent
gpu=os.environ.get('CUDA_VISIBLE_DEVICES', '0')
p=argparse.ArgumentParser();p.add_argument('variant');p.add_argument('label');p.add_argument('extra',nargs=argparse.REMAINDER)
a=p.parse_args()
d=root/'measurements';d.mkdir(exist_ok=True);prefix=d/(a.label+'-'+a.variant)
args=[root/a.variant,'-d','0','--stopping-criterion','entropy','--cold-warmup-runs','15','--min-samples','60','--timeout','2','--md',prefix.with_suffix('.md'),'--json',prefix.with_suffix('.json'),*a.extra]
with prefix.with_suffix('.log').open('w') as log:
 log.write(' '.join(str(x) for x in args)+'\n');log.flush()
 start=time.time()
 subprocess.run(args,env={**os.environ,'CUDA_VISIBLE_DEVICES':gpu},stdout=log,stderr=subprocess.STDOUT,check=True)
m=prefix.with_suffix('.md').read_text(); d=json.loads(prefix.with_suffix('.json').read_text())
print(a.label,a.variant,round(time.time()-start,1),'s; JSON sections:',list(d), 'rows',len(re.findall('Cold:',m)))
for row in m.splitlines():
 if 'skip' in row.lower() or 'error' in row.lower() or 'fail' in row.lower():print(row[:350])
