import os,pathlib,subprocess,sys,shlex
out=pathlib.Path(__file__).resolve().parent
variant=sys.argv[1];src=pathlib.Path(sys.argv[2]);nvbench_src=pathlib.Path(os.environ['NVBENCH_SOURCE']); nvbench_build=pathlib.Path(os.environ['NVBENCH_BUILD'])
nv=pathlib.Path(os.environ.get('CUDA_PATH','/usr/local/cuda-13.5'))
include_dirs = ['cub', 'cudax/include', 'libcudacxx/include', 'thrust']
args=[nv/'bin/nvcc','-arch=sm_120a',f"-ccbin={os.environ.get('CXX','/usr/bin/g++-14')}",'-std=c++17','-O3','-DNDEBUG','-Xptxas=-v','-lineinfo','--expt-relaxed-constexpr',*[f'-I{src}/{part}' for part in include_dirs],f'-I{nvbench_src}',f'-I{nvbench_build}/nvbench',out/('graph.cu' if variant.endswith('graph') else 'workload.cu'),f'-L{nvbench_build}/lib',f'-Xlinker=-rpath={nvbench_build}/lib','-lnvbench_main','-lnvbench',f'-L{nv}/lib64/stubs','-lcuda','--cudart=shared','-o',out/variant]
if 'WARP_GRAPH_REPEATS' in os.environ: args.insert(1, f"-DWARP_BENCH_GRAPH_REPEATS={int(os.environ['WARP_GRAPH_REPEATS'])}")
if len(sys.argv)>3:args[1:1]=[f'-I{path}' for path in sys.argv[3:]]
with (out/(variant+'.build.log')).open('w') as f:
 f.write(shlex.join(map(str,args))+'\n'); f.flush()
 subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)
for flag,suffix in [('--dump-resource-usage','resources'),('--dump-sass','sass')]:
 with (out/(variant+'.'+suffix)).open('w') as f: subprocess.run([nv/'bin/cuobjdump',flag,out/variant],stdout=f,check=True)
