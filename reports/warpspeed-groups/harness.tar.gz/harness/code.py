from pathlib import Path
from collections import Counter
import re,json,sys,subprocess,difflib,csv
root=Path(__file__).resolve().parent
def parse(ver):
 txt=(root/(ver+'.sass')).read_text(); out={}
 for part in re.split(r'\s*Function : ',txt)[1:]:
  func,_,body=part.partition('\n')
  label='rle_floor' if 'forced_rleILb0' in func else 'rle_staged' if 'forced_rleILb1' in func else 'scan_u32' if 'IPjS' in func else 'scan_u64' if 'IPmS' in func else None
  if not label or 'InitKernel' in func:continue
  if 'DeviceScanKernel' not in func and 'DeviceRleEncodeLookaheadKernel' not in func:continue
  lines=[(int(a,16),o.strip()) for a,o in re.findall(r'/\*([a-f0-9]{4,})\*/\s+([^;/]+)\s*;',body)]
  op=[re.sub(r'^@!?[A-Z0-9]+ ', '',o).split()[0] for _,o in lines]
  def canon(s):
   s=re.sub(r'^@(!?)(U?P)(?:T|\d+) ',r'@\1\2 ',s)
   s=re.sub(r'\b(R|UR|UP|P|B|SB)(?:Z|T|\d+)\b',r'\1',s)
   if re.search(r'\b(?:BRA|BSSY|CALL|BREAK|BRX|JMX)',s): s=re.sub(r'0x[\da-f]+(?=\s*$)','target',s)
   return s.strip()
  out[label]=dict(symbol=func,instructions=lines,opcodes=op,normalized=[canon(o) for _,o in lines],opcounts=Counter(op))
 return out
a,b=sys.argv[1:3]
x,y=parse(a),parse(b)
for k in x:
 p,q=x[k],y[k]; print(k,len(p['instructions']),len(q['instructions']),sorted((op,q['opcounts'][op]-p['opcounts'][op]) for op in (set(p['opcounts'])|set(q['opcounts'])) if q['opcounts'][op]!=p['opcounts'][op]))
 for ver,h in ((a,p),(b,q)):
  (root/f'{ver}-{k}.normalized').write_text('\n'.join(h['normalized'])+'\n')
 diff=list(difflib.unified_diff(p['normalized'],q['normalized'],a+'-'+k,b+'-'+k,lineterm=''))
 (root/f'{a}-{b}-{k}.diff').write_text('\n'.join(diff)+'\n')
 print('barriers',[(ver,[s for _,s in h['instructions'] if 'BAR.SYNC' in s]) for ver,h in ((a,p),(b,q))])
