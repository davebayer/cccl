"""Summarize paired medians. Bootstrap the paired ratio rather than pooling individual kernel launches."""
import os,pathlib,json,csv,statistics,random,math,sys
from collections import defaultdict
root=pathlib.Path(__file__).resolve().parent; variant=sys.argv[1];tag=sys.argv[2];baseline=os.environ.get('WARP_BASELINE','old');scale=int(os.environ.get('WARP_GRAPH_REPEATS','24')) if baseline.endswith('graph') else 1
def read(p):
 d=json.loads(p.read_text());rows={}
 for b in d['benchmarks']:
  for s in b['states']:
   assert not s['is_skipped'],str(p)+str(s.get('skip_reason'))
   v={q['tag']:float(q['data'][0]['value']) for q in s['summaries'] if q.get('data')}
   key=(b['name'],*(int(x['value']) for x in s['axis_values']))
   rows[key]=(v['nv/cold/time/gpu/median']*1e6/scale,v['nv/cold/sample_size'],v['nv/cold/sm_clock_rate/mean']*1e-6,v['nv/cold/time/gpu/iqr/relative'])
 return rows
rows=[];agg=defaultdict(list)
for base in sorted((root/'measurements').glob(tag+f'[0-9][0-9]-{baseline}.json')):
 cand=base.with_name(base.name.replace(f'-{baseline}.json',f'-{variant}.json'));old=read(base);new=read(cand)
 assert old.keys()==new.keys()
 for k in old:
  agg[k].append((old[k],new[k]))
  rows.append((*k,base.name,*(old[k]+new[k])))
fields=['workload','N','layout_or_run','round','old_us','old_samples','old_MHz','old_IQR','new_us','new_samples','new_MHz','new_IQR']
with (root/(tag+'-pairs.csv')).open('w') as f:
 w=csv.writer(f);w.writerow(fields);w.writerows(rows)
def median(x):return statistics.median(x)
def pct(a,f):return a[round((len(a)-1)*f)]
summary=[];rng=random.Random(46821)
for k,vs in agg.items():
 old,new=zip(*vs); rel=[(n[0]/b[0]-1)*100 for b,n in vs];boot=sorted(median(rng.choices(rel,k=len(rel))) for _ in range(5000))
 summary.append((*k,median([b[0] for b in old]),median([n[0] for n in new]),median(rel),pct(boot,.025),pct(boot,.975),min(rel),max(rel),median([b[2] for b in old]),median([n[2] for n in new]),sum(b[1] for b in old),sum(n[1] for n in new)))
with (root/(tag+'-summary.csv')).open('w') as f:
 w=csv.writer(f);w.writerow(['workload','N','layout_or_run','baseline_us','candidate_us','paired_delta_pct','ci95_low','ci95_high','min_pair_pct','max_pair_pct','old_MHz','new_MHz','old_samples','new_samples']);w.writerows(summary)
for t in sorted(summary):
 print(f'{t[0]:10} N=2^{int(math.log2(t[1])):2} opt={t[2]:3} {t[3]:8.2f} -> {t[4]:8.2f} {t[5]:+6.2f}%  [{t[6]:+6.2f}, {t[7]:+6.2f}] MHz {t[10]:.0f}/{t[11]:.0f}')
