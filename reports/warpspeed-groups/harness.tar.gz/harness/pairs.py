"""Alternating baseline and candidate launch order; avoid simultaneous GPU work."""
from pathlib import Path
import os, argparse, subprocess, json, hashlib,time
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('candidate');p.add_argument('tag');p.add_argument('pairs',type=int);p.add_argument('extra',nargs=argparse.REMAINDER)
a=p.parse_args(); baseline=os.environ.get('WARP_BASELINE','old')
plan=[(i,side) for i in range(a.pairs) for side in ((baseline,a.candidate) if i%2==0 else (a.candidate,baseline))]
for side in (baseline,a.candidate):
    print(side,hashlib.sha256((root/side).read_bytes()).hexdigest(),flush=True)
for i,side in plan:
    subprocess.run(['python3',root/'run.py',side,f'{a.tag}{i:02d}',*a.extra],check=True)
